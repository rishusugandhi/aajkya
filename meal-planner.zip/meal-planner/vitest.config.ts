import { defineConfig } from "vitest/config";
import path from "node:path";

export default defineConfig({
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  test: {
    environment: "node",
    server: {
      deps: {
        external: ["node:sqlite"],
      },
    },
  },
  ssr: {
    external: ["node:sqlite"],
  },
});
